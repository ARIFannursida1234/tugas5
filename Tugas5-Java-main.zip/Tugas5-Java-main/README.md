# Tugas5-Java

Nama  : Rizky Adi Ryanto<br>
Nim   : 1901013044<br>
Kelas : PBO B<br>

# Demo
<img src="https://github.com/Rizky1408/Tugas5-Java/blob/main/Tugas5.1.png" width="500">
<img src="https://github.com/Rizky1408/Tugas5-Java/blob/main/Tugas5.2.png" width="500">
<img src="https://github.com/Rizky1408/Tugas5-Java/blob/main/Tugas5.3.png" width="500">
<img src="https://github.com/Rizky1408/Tugas5-Java/blob/main/Tugas5.4.png" width="500">
